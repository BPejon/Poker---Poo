import java.awt.BorderLayout;
import java.awt.ComponentOrientation;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class VisualCodigo extends JFrame implements ActionListener {
	
	JTextField nome;
	JLabel label;
	
	public VisualCodigo() {
		super("Video Poker");
		JPanel painel = (JPanel) this.getContentPane();
		painel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		painel.setLayout(new GridLayout(3,1));
		
		JMenuBar menubar = new JMenuBar();
		this.setJMenuBar(menubar);
		JMenu iconemenu = new JMenu("Arquivos");
		menubar.add(iconemenu);
		
		JMenuItem menuitem = new JMenuItem("Abrir");
		menuitem.setActionCommand("abrir");
		menuitem.addActionListener(this);
		iconemenu.add(menuitem);
		
		iconemenu.addSeparator();
		
		menuitem = new JMenuItem("Fechar");
		iconemenu.add(menuitem);
	
		menuitem = new JMenuItem("Regras");
		iconemenu.add(menuitem);
		
		JMenu ajuda = new JMenu("Ajuda");
		iconemenu.add(ajuda);
		
		/*
		ajuda = new JMenuItem("Pontuacao");
		iconemenu.add(ajuda);
		
		*/
		
		
		label = new JLabel("Digite o que voce quer q eu printe");
		nome = new JTextField();
		JButton buttonOK = new JButton("Confirma");
		
		painel.add(label);
		painel.add(nome);
		painel.add(buttonOK);
		
		nome.getText();
		buttonOK.setActionCommand("buttonOk");
		buttonOK.addActionListener(this);
	
	}
	 
	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
			case "buttonOk":
				String s = nome.getText();
				label.setText(s);
				
				break;
		}
	}
	
	/*public void Interact() {
		super("Hello world")
	}*//*
	public static void  main (String[] args) {
		 VisualCodigo frame = new VisualCodigo();
		 frame.setVisible(true);
		 frame.setSize(1200, 800);
		 frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
	 }
	 
*
}
