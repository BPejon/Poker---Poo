import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InterfaceAposta extends JFrame implements ActionListener   {

	public static Placar placar = new Placar(); 		//estático para nao mudar ao trocar de janela


	private static InterfaceAposta frame;
	

	private JPanel painel;
	private JPanel painelAposta;
	private JPanel painelOpcoes;
	
	private JLabel Finalizar;
	private JButton botaoFinalizar;
	
	
	private JButton botaoAposta;
	private JTextField getAposta;
	private JLabel qntAposta;
	
	private JLabel valorAposta;
	
	
	
	
	public InterfaceAposta(){			//dando erro quando coloco throws IOException
		super("Video Poker Aposta");		
	
		
		//tratar o erro maldito//
		Image IconebotaoAposta = null;
		Image IconebotaoSair = null;
		try {
			IconebotaoAposta = ImageIO.read(getClass().getResource("resources/iconecarta.png"));
			IconebotaoSair = ImageIO.read(getClass().getResource("resources/iconesair.png"));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		//tratar o erro maldito//
		
		
		painel = (JPanel) this.getContentPane();
		painel.setLayout(new GridLayout(2,1));
		
		

		
		//-----------------GRID A CIMA -- APOSTA----------//
		painelAposta = new JPanel(new GridLayout(3,1));
		painelAposta.setLayout(new GridLayout(3,1));
		
		
		qntAposta = new JLabel("Quanto deseja apostar?");
		painelAposta.add(qntAposta);
		
		
		getAposta = new JTextField();
		painelAposta.add(getAposta);
		
		//----------------Botao Get Aposta--------------//
		botaoAposta = new JButton("Apostar", new ImageIcon(IconebotaoAposta));
		botaoAposta.setActionCommand("botaoAposta");
		botaoAposta.addActionListener(this);
		botaoAposta.setToolTipText("Precione para fazer sua aposta");
		
		painelAposta.add(botaoAposta);		
		painel.add(painelAposta);
			
		
		
		//-----------------GRID ABAIXO -- RESULTADO--------//
		painelOpcoes = new JPanel(new GridLayout(3,1));;
		
		valorAposta = new JLabel();
		valorAposta.setText("<html>Créditos disponíveis: <html>"+ placar.getCreditos());	
		painelOpcoes.add(valorAposta);
		
		Finalizar = new JLabel("Deseja finalizar o jogo?");
		painelOpcoes.add(Finalizar);
		
		botaoFinalizar = new JButton("Finalizar", new ImageIcon(IconebotaoSair));
		botaoFinalizar.setActionCommand("Finalizar");
		botaoFinalizar.addActionListener(this);
		painelOpcoes.add(botaoFinalizar);
		
		painel.add(painelOpcoes);
		
		
		
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
			//pega a aposta do usuario
			case "botaoAposta":
				dispose();
				String s = getAposta.getText();
				int aposta = Integer.parseInt(s);
				try {
					placar.setAposta(aposta);
				} catch (Exception e1) {
				}
				
				InterfaceGameplay game = new InterfaceGameplay();
				game.setDefaultCloseOperation(EXIT_ON_CLOSE);
				game.setVisible(true);
				game.setSize(this.getSize());
				game.setLocation(this.getLocation());
							
				
				break;
			
			case "Finalizar":
				dispose();
		}
		
	}
	
	
	

}
