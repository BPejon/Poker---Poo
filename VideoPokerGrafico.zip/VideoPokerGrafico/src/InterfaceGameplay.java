import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class InterfaceGameplay extends JFrame implements ActionListener {

	public static Carta cartas = new Carta();
	private JPanel painel;
	private JPanel painelCartas;
	
	private JButton botao;
	
	private JCheckBox UM, DOIS, TRES, QUATRO, CINCO;
	
	
	public InterfaceGameplay() {
		
		super("Video Poker Gameplay");
		
		painel = (JPanel) this.getContentPane();
		painel.setLayout(new GridLayout(2,1));
		
		
		
		
		painelCartas = new JPanel();
		painelCartas.setLayout(new FlowLayout());
		
		//--------CHECKBOX	--------//
		UM = new JCheckBox("UM");
		DOIS = new JCheckBox("DOIS");
		TRES = new JCheckBox("TRES");
		QUATRO = new JCheckBox("QUATRO");
		CINCO = new JCheckBox("CINCO");
		
		UM.setActionCommand(actionCommand);
		UM.addActionListener(l);
		
		painelCartas.add(UM);
		painelCartas.add(DOIS);
		painelCartas.add(TRES);
		painelCartas.add(QUATRO);
		painelCartas.add(CINCO);
		
		CheckBoxHandler tratador = new CheckBoxHandler();
		
		JCheckBox checkbox = new JCheckBox();
		
		painel.add(painelCartas);
		
		botao = new JButton ("INTERFACAE GAMEPLAY");
		botao.setActionCommand("Interfaceaposta");
		botao.addActionListener(this);
		painel.add(botao);
		
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
		case "Interfaceaposta":
			dispose();
			InterfaceAposta aposta = new InterfaceAposta();
			aposta.setDefaultCloseOperation(EXIT_ON_CLOSE);
			aposta.setVisible(true);			
			aposta.setSize(this.getSize());
			aposta.setLocation(300, 300);
			
			if(UM.is)
		}
		
	}
	
}
