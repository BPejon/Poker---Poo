import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class InterfaceGameplay extends JFrame implements ActionListener {

	public static Carta cartas = new Carta();
	
	private JPanel painel;
	private JPanel painelCartas;
	private JPanel painelOpcoes;
	private JPanel painelTrocas;
	
	private JButton Trocar;			//botao para trocar as cartas selecionadas
	private JButton Terminar;		//botao para continuar para o resultado
	
	private JLabel trocasDisp;
	
	private JCheckBox UM, DOIS, TRES, QUATRO, CINCO;	//checkboxs das cartas
	
	int trocasDisponiveis = 2;
	
	
	public InterfaceGameplay() {
		
		super("Video Poker Gameplay");
		
		painel = (JPanel) this.getContentPane();
		painel.setLayout(new GridLayout(2,1));
		
		
		
		
		painelCartas = new JPanel();
		painelCartas.setLayout(new FlowLayout());
		
		//--------CHECKBOX	--------//
		UM = new JCheckBox("UM");
		DOIS = new JCheckBox("DOIS");
		TRES = new JCheckBox("TRES");
		QUATRO = new JCheckBox("QUATRO");
		CINCO = new JCheckBox("CINCO");
		
		UM.setActionCommand("UM");
		UM.addActionListener(this);
		DOIS.setActionCommand("UM");
		DOIS.addActionListener(this);
		TRES.setActionCommand("UM");
		TRES.addActionListener(this);
		QUATRO.setActionCommand("UM");
		QUATRO.addActionListener(this);
		CINCO.setActionCommand("UM");
		CINCO.addActionListener(this);
		
		
		painelCartas.add(UM);
		painelCartas.add(DOIS);
		painelCartas.add(TRES);
		painelCartas.add(QUATRO);
		painelCartas.add(CINCO);
		
		//CheckBoxHandler tratador = new CheckBoxHandler();
		
		JCheckBox checkbox = new JCheckBox();
		
		painel.add(painelCartas);
		
		//--------Painel de opcoes-------------------//
		painelOpcoes = new JPanel(new GridLayout(1,2));
		painelTrocas = new JPanel(new GridLayout(2,1));
		
		Trocar = new JButton ("Trocar Cartas");
		Trocar.setActionCommand("Trocar");
		Trocar.addActionListener(this);
		painelTrocas.add(Trocar);
		
		trocasDisp = new JLabel();
		trocasDisp.setText("Voc� possui " +trocasDisponiveis + " trocas dispon�veis");
		painelTrocas.add(trocasDisp);
		
		
		painelOpcoes.add(painelTrocas);
		
		Terminar= new JButton ("Terminar Rodada");
		Terminar.setActionCommand("Terminar");
		Terminar.addActionListener(this);
		painelOpcoes.add(Terminar);
		
		painel.add(painelOpcoes);
		
		
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
		case "Trocar":
		
		break;
		
		case "Terminar":
			
		case"UM":
			JCheckBox box = (JCheckBox) e.getSource();
			if(box. == UM) 
				 System.out.println("Checkbox #1 is clicked");
			else 
				 System.out.println("Checkbox #1 is disclicked");
			if( box == DOIS)
				 System.out.println("Checkbox #2 is clicked");
			else
				 System.out.println("Checkbox #1 is disclicked");
			if (box == TRES)
				 System.out.println("Checkbox #3 is clicked");
			
			if (box == QUATRO)
				 System.out.println("Checkbox #4 is clicked");
			if(box == CINCO)
				 System.out.println("Checkbox #5 is clicked");
			break;
			}
		}
		
	}
