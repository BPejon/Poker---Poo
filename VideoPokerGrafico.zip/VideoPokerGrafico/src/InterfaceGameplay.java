import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class InterfaceGameplay extends JFrame implements ActionListener {
		
	/*CARTAS
	 * 2 - 10 = Valores do baralho
	 * 11 = Valete
	 * 12 = Dama
	 * 13 = Rei
	 * 14 = As
	 */
	
	/* NAIPES
	 * 1 = OUROS 
	 * 2 = ESPADAS
	 * 3 = COPAS
	 * 4 = PAUS
	 */

	//daria pra ter feito enum tmb
	/*Código das Cartas:
	* carta<numero da carta><numero do naipe>
	*/
	
	public static Carta cartas = new Carta();
	
	private int mao[] = new int[5];
	private int naipe[]= new int [5];
	
	private JPanel painel;
	private JPanel painelCartas;
	private JPanel painelCarta1;
	private JPanel painelCarta2;
	
	private JPanel painelOpcoes;
	private JPanel painelTrocas;
	
	private JButton Trocar;			//botao para trocar as cartas selecionadas
	private JButton Terminar;		//botao para continuar para o resultado
	
	private JLabel trocasDisp;
	
	//chekboxs das cartas
	private JCheckBox UM, DOIS, TRES, QUATRO, CINCO;
	//imagem das cartas 
	private Image[] carta = new Image[5];
	
	int trocasDisponiveis = 2;
	
	
	public InterfaceGameplay() {
		super("Video Poker Gameplay");
		
		cartas.randDraw();
		cartas.displayHand(); 
		
		mao = cartas.getMao();
		naipe = cartas.getNaipe();
		
		//adciona as imagens nas cartas de acordo com o codigo passado
		try {
			carta[0]= ImageIO.read(new File("./resources/cartas/carta" + 3 + 1+ ".png"));
		} catch (IOException e) {
		}
		/*
		for(int i = 0; i<5; ++i) {
			try {
				carta[i] = ImageIO.read(new File("./resources/cartas/carta" + mao[i] + naipe[i]));
			}catch(Exception e){
			}
		}
			
		
		
	*/
		
		painel = (JPanel) this.getContentPane();
		painel.setLayout(new GridLayout(2,1));
		
		
		
		
		
		painelCartas = new JPanel(new GridLayout(1,5));
		painelCartas.setLayout(new FlowLayout());
		
		//--------CHECKBOX	--------//
		painelCarta1 = new JPanel(new GridLayout(2,1));
		
		painelCarta1.add(imagemcarta1);
		painelCarta1.add(Checkbox1);
		
		painelCartas.add(painelCarta1);
		
		UM = new JCheckBox("UM", new ImageIcon(carta[0]));
		/*
		DOIS = new JCheckBox("DOIS", new ImageIcon(carta[1]));
		
		TRES = new JCheckBox("TRES", new ImageIcon(carta[2]));
		
		QUATRO = new JCheckBox("QUATRO", new ImageIcon(carta[3]));
		
		CINCO = new JCheckBox("CINCO", new ImageIcon(carta[4]));
		*/
		/*NAO PRECISA ACTION COMMAND PARA CHECKBOX
		 * VERIFICAR SE ESTA SELECIONADA NO FINAL DA TROCA
		 *
	
		painelCartas.add(UM);
		painelCartas.add(DOIS);
		painelCartas.add(TRES);
		painelCartas.add(QUATRO);
		painelCartas.add(CINCO);
		*/
		//CheckBoxHandler tratador = new CheckBoxHandler();
		painelCartas.add(UM); 	//arrumar aqui
		
		painel.add(painelCartas);
		
		//------------Painel de opcoes-------------------//
		painelOpcoes = new JPanel(new GridLayout(1,2));
		painelTrocas = new JPanel(new GridLayout(2,1));
		
		Trocar = new JButton ("Trocar Cartas");
		Trocar.setActionCommand("Trocar");
		Trocar.addActionListener(this);
		painelTrocas.add(Trocar);
		
		trocasDisp = new JLabel();
		trocasDisp.setText("Voc� possui " +trocasDisponiveis + " trocas dispon�veis");
		painelTrocas.add(trocasDisp);
		
		
		painelOpcoes.add(painelTrocas);
		
		Terminar= new JButton ("Terminar Rodada");
		Terminar.setActionCommand("Terminar");
		Terminar.addActionListener(this);
		painelOpcoes.add(Terminar);
		
		painel.add(painelOpcoes);
		
		
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
		case "Trocar":
		
			break;
		
		case "Terminar":
			
			break;
			
		case"UM":
			JCheckBox box = (JCheckBox) e.getSource();
			if(box == UM) 
				 System.out.println("Checkbox #1 is clicked");
			else 
				 System.out.println("Checkbox #1 is disclicked");
			if( box == DOIS)
				 System.out.println("Checkbox #2 is clicked");
			else
				 System.out.println("Checkbox #1 is disclicked");
			if (box == TRES)
				 System.out.println("Checkbox #3 is clicked");
			
			if (box == QUATRO)
				 System.out.println("Checkbox #4 is clicked");
			if(box == CINCO)
				 System.out.println("Checkbox #5 is clicked");
			break;
			}
		}
		
	}
