import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class InterfaceUnificada extends JFrame implements ActionListener {

	private JPanel painel;
	private JPanel paiAposta;
	
	private JLabel qntAposta;
	private JTextField getAposta;
	private JButton botaoAposta;
	

	
	public InterfaceUnificada(){
		super("Video Poker Jogo");
		
		painel = (JPanel) this.getContentPane();
		painel.setLayout(new GridLayout(2,1));
		
		paiAposta = new JPanel;
		paiAposta.setLayout(new GridLayout(3,1));
		
		
		
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	

}
