import java.awt.Button;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class InterfaceGrafica extends JFrame implements ActionListener{
	private static InterfaceGrafica frame;
	private JPanel painel;
	private JButton botaoPlay;
	InterfaceGrafica frame2;
	//ImageIcon IconebotaoPlay = createImageIcon("images/leandro.jpg");
	
	String mensagemIntro = "<html>Video Poker <br/>"
			 + " Projeto de Programação Orientada a Objetos <br/>"
			 + "Alunos : <br/> "
			 + "Breno Pejon Rodrigues <br/> "
			 + "Lucas Ebling</html";
	
	
	//outra opcao de colocar imagem, porem essa esta vinculada a origem do arquivo
	//ImageIcon bot = new ImageIcon("/home/pao/Documentos/poo/videopokerinterface/VideoPokerGrafico/resources/play.png");
	
	//melhor opcao de adcionar icone pois nao eh atrelada ao endereco do arquivo
	//pega a imagem da pasta resources em class
	Image IconebotaoPlay = ImageIO.read(getClass().getResource("resources/playgrande.png"));
	
	JPanel painel2;
	JButton botaoPlay2;
	
	
	//onde será instanciado todos os botões, janelas e outros
	public InterfaceGrafica() throws IOException {
		super("Video Poker");
		painel = (JPanel) this.getContentPane();
		painel.setLayout(new GridLayout(2,1));
		
		
		JLabel intro = new JLabel(mensagemIntro);
		painel.add(intro);
		
		
		//-----------------Botão para inciar a gameplay--------------------//
		//botaoPlay.setIcon(new ImageIcon(IconebotaoPlay));
			
		botaoPlay = new JButton("Começar o Jogo", new ImageIcon(IconebotaoPlay));
		botaoPlay.setBounds(12, 86, 424, 176);										//localicacao do botao									
		botaoPlay.setActionCommand("botaoPlay");									//qual sera o comando de acao
		botaoPlay.addActionListener(this);											//aciona o listener
		botaoPlay.setToolTipText("Aperte o botao para inciar");						//pop upp de dica

		painel.add(botaoPlay);

		
		

		
		
		
		
	}
	
	
	
	
	//Lugar onde será executado as funções dos botoes e afins
	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
			case "botaoPlay":
				dispose();
				
				/*
				InterfaceUnificada jogo = new InterfaceUnificada();
				jogo.setDefaultCloseOperation(EXIT_ON_CLOSE);
				jogo.setVisible(true);
				jogo.setSize(this.getSize());
				jogo.setLocation(300,300);
				
				*/
				
				
				
				
				InterfaceAposta aposta = new InterfaceAposta();
				aposta.setDefaultCloseOperation(EXIT_ON_CLOSE);
				aposta.setVisible(true);			
				aposta.setSize(frame.getSize());
				aposta.setLocation(300, 300);
				
				break;
				
				
		
		
		}
		
	}

	
	//inicialização da interface gráfica
	public static void main(String[] args) throws IOException{
					frame = new InterfaceGrafica();
					frame.setSize(1200,1200);
					frame.setLocation(300, 300);
					frame.setDefaultCloseOperation(EXIT_ON_CLOSE);		//por default vem hide on close
					frame.setVisible(true);
			
	}

}


