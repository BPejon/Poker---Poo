import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class InterfaceGameplay extends JFrame implements ActionListener {
		
	/*CARTAS
	 * 2 - 10 = Valores do baralho
	 * 11 = Valete
	 * 12 = Dama
	 * 13 = Rei
	 * 14 = As
	 */
	
	/* NAIPES
	 * 1 = OUROS 
	 * 2 = ESPADAS
	 * 3 = COPAS
	 * 4 = PAUS
	 */

	//daria pra ter feito enum tmb
	/*Código das Cartas:
	* carta<numero da carta><numero do naipe>
	*/
	
	public static Placar placar; //vamos copiar o placar que temos antes;
	
	
	public static Carta cartas = new Carta();
	
	public int mao[] = new int[5];
	public int naipe[]= new int [5];
	
	private JPanel painel;
	private JPanel painelCartas;
	private JPanel painelCarta1;
	private JPanel painelCarta2;
	private JPanel painelCarta3;
	private JPanel painelCarta4;
	private JPanel painelCarta5;
	
	private JPanel painelOpcoes;
	private JPanel painelTrocas;
	
	private JButton Trocar;			//botao para trocar as cartas selecionadas
	private JButton Terminar;		//botao para continuar para o resultado
	
	private JLabel trocasDisp;
	
	//Chekboxs das cartas
	private JCheckBox checkbox1, checkbox2, checkbox3, checkbox4, checkbox5;
	//imagem das cartas 
	private Image[] carta = new Image[5];
	//Label das imagens das cartas
	private JLabel carta1, carta2, carta3, carta4, carta5;
	
	int trocasDisponiveis = 2;
	
	
	public InterfaceGameplay(Placar p) {
		super("Video Poker Gameplay");
		
		cartas.randDraw();
		cartas.displayHand(); 
		
		mao = cartas.getMao();
		naipe = cartas.getNaipe();
		
		//adciona as imagens nas cartas de acordo com o codigo passado
		try {
			for(int i =0; i<5; ++i) 
				carta[i]= ImageIO.read(new File("./resources/cartas/carta" + mao[i] + naipe[i]+ ".png"));
		} catch (IOException e) {				
		}
	
		
		painel = (JPanel) this.getContentPane();
		painel.setLayout(new GridLayout(2,1));
		
		
		
		
		painelCartas = new JPanel(new GridLayout(1,5));
		painelCartas.setLayout(new FlowLayout());
		
		//------------------------CARTAS----------------------//
		painelCarta1 = new JPanel(new GridLayout(2,-1));
		painelCarta2 = new JPanel(new GridLayout(2,1));
		painelCarta3 = new JPanel(new GridLayout(2,1));
		painelCarta4 = new JPanel(new GridLayout(2,1));
		painelCarta5 = new JPanel(new GridLayout(2,1));	
				
		//inicializar imagens das cartas
		carta1 = new JLabel(new ImageIcon(carta[0]));	//primeira carta
		carta2 = new JLabel(new ImageIcon(carta[1]));	//segunda carta
		carta3 = new JLabel(new ImageIcon(carta[2]));	//terceira carta
		carta4 = new JLabel(new ImageIcon(carta[3]));	//quarta carta
		carta5 = new JLabel(new ImageIcon(carta[4]));	//quinta carta		
		
		//inicializar checkbox das cartas
		checkbox1 = new JCheckBox("Trocar");	
		checkbox2 = new JCheckBox("Trocar");
		checkbox3 = new JCheckBox("Trocar");
		checkbox4 = new JCheckBox("Trocar");
		checkbox5 = new JCheckBox("Trocar");
		
		//Setar os paineis
		painelCarta1.add(carta1);
		painelCarta1.add(checkbox1);
		painelCarta2.add(carta2);
		painelCarta2.add(checkbox2);
		painelCarta3.add(carta3);
		painelCarta3.add(checkbox3);
		painelCarta4.add(carta4);
		painelCarta4.add(checkbox4);
		painelCarta5.add(carta5);
		painelCarta5.add(checkbox5);

		painelCartas.add(painelCarta1);
		painelCartas.add(painelCarta2);
		painelCartas.add(painelCarta3);
		painelCartas.add(painelCarta4);
		painelCartas.add(painelCarta5);
		
		
		painel.add(painelCartas);
		
		//-------------------Painel de opcoes---------------------//
		painelOpcoes = new JPanel(new GridLayout(1,2));
		painelTrocas = new JPanel(new GridLayout(2,1));
		
		Trocar = new JButton ("Trocar Cartas");
		Trocar.setActionCommand("Trocar");
		Trocar.addActionListener(this);
		painelTrocas.add(Trocar);
		
		trocasDisp = new JLabel();
		trocasDisp.setText("Voc� possui " +trocasDisponiveis + " trocas dispon�veis");
		painelTrocas.add(trocasDisp);
		
		
		painelOpcoes.add(painelTrocas);
		
		Terminar= new JButton ("Terminar Rodada");
		Terminar.setActionCommand("Terminar");
		Terminar.addActionListener(this);
		painelOpcoes.add(Terminar);
		

		painel.add(painelOpcoes);
		
		placar = p;
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		switch(e.getActionCommand()) {
		case "Trocar":
			//caso ainda poussi trocas
			if(trocasDisponiveis >0) {
				--trocasDisponiveis;
				trocasDisp.setText("Você possui " +trocasDisponiveis + " trocas disponíveis");
				
				//CODIGO DA TROCA AQUI
				
				//dependendo das checkboxes iremos trocar as cartas;
				String troca = ""; 
				int flag = 0;
				
				
				//conforme os que foram selecionados, colocamos novos;
				if(checkbox1.isSelected())
				{
					flag++;
					troca = troca + "0 ";
				}
				
				if(checkbox2.isSelected())
				{
					flag++;
					troca = troca + "1 ";
				}
				
				if(checkbox3.isSelected())
				{
					flag++;
					troca = troca + "2 ";
				}
				
				if(checkbox4.isSelected())
				{
					flag++;
					troca = troca + "3 ";
				}
				
				if(checkbox5.isSelected())
				{
					flag++;
					troca = troca + "4 ";
				}
				
				if(flag > 0) //se ha algo a trocar;
				{
					cartas.partialDraw(troca);
				}
				//trocamos os valores, atualizamos as imagens
				
				mao = cartas.getMao();
				naipe = cartas.getNaipe();
				
				//refazemos as cartas;
				try {
					for(int i =0; i<5; ++i) 
						carta[i]= ImageIO.read(new File("./resources/cartas/carta" + mao[i] + naipe[i]+ ".png"));
				} catch (IOException OhNO) {				
				}
				
				
				//atualizamos as fotos;
				carta1.setIcon(new ImageIcon(carta[0]));
				carta2.setIcon(new ImageIcon(carta[1]));
				carta3.setIcon(new ImageIcon(carta[2]));
				carta4.setIcon(new ImageIcon(carta[3]));
				carta5.setIcon(new ImageIcon(carta[4]));
				
			}
			break;
		
		case "Terminar":
			//CODIGO DO TERMINAR AQUI
			//IR PARA RESULTADO E PASSAR A MAO E O NAIPE DAS CARTAS NO INTERFACEAPOSTA
			placar.Pontuacao(mao, naipe); //atualizamos quanto o jogador tem;
			
			dispose(); //se livramos do antigo;
			
			InterfaceAposta menu = new InterfaceAposta(placar);
			menu.setDefaultCloseOperation(EXIT_ON_CLOSE);
			menu.setVisible(true);
			menu.setSize(this.getSize());
			menu.setLocation(this.getLocation());
						
			
			
			break;
		
		}
	}
	
}